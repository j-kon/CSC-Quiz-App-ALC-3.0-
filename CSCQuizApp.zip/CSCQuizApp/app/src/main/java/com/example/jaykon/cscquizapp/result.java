package com.example.jaykon.cscquizapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class result extends Activity{
    TextView counts;
    String CORRECT_CHOICE1 = "";
    String CORRECT_CHOICE2 = "";
    String CORRECT_CHOICE3 = "";
    String CORRECT_CHOICE4 = "";
    int count = 0;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result);

        counts = findViewById(R.id.count);
        String question1_choice = getIntent().getStringExtra("option1");
        String question2_choice = getIntent().getStringExtra("option2");
        String question3_choice = getIntent().getStringExtra("option3");
        String question4_choice = getIntent().getStringExtra("option4");

        if(question1_choice.equals(CORRECT_CHOICE1)){
            count+=1;
        }
        else if(question2_choice.equals(CORRECT_CHOICE2)){
            count+=1;
        }
        else if(question3_choice.equals(CORRECT_CHOICE3)){
            count+=1;
        }
        else if(question4_choice.equals(CORRECT_CHOICE4)){
            count+=1;
        }

        counts.setText("You got "+count);

    }
}
