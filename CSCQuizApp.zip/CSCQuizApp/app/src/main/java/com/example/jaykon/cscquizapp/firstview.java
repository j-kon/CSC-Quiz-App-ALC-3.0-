package com.example.jaykon.cscquizapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class firstview extends AppCompatActivity {


    RadioButton question1_choice,question2_choice,question3_choice,question4_choice;
    RadioGroup option1, option2, option3, option4;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstview);

        submit = findViewById(R.id.submit);
       option1 = findViewById(R.id.option1);
       option2 = findViewById(R.id.option2);
       option3 = findViewById(R.id.option3);
       option4 = findViewById(R.id.option4);

       submit.setOnClickListener(new View.OnClickListener() {
           @SuppressLint("ResourceType")
           @Override
           public void onClick(View view) {
               if(option1.getCheckedRadioButtonId() > 0 && option2.getCheckedRadioButtonId() > 0 && option3.getCheckedRadioButtonId() > 0 && (option4.getCheckedRadioButtonId() > 0)){
                    int opid1 = option1.getCheckedRadioButtonId();
                    int opid2 = option2.getCheckedRadioButtonId();
                    int opid3 = option3.getCheckedRadioButtonId();
                    int opid4 = option4.getCheckedRadioButtonId();

                   question1_choice = findViewById(opid1);
                   question2_choice = findViewById(opid2);
                   question3_choice = findViewById(opid3);
                   question4_choice = findViewById(opid4);

                   Intent result = new Intent(firstview.this, result.class);
                   result.putExtra("option1", question1_choice.getText().toString());
                   result.putExtra("option2", question2_choice.getText().toString());
                   result.putExtra("option3", question3_choice.getText().toString());
                   result.putExtra("option4", question4_choice.getText().toString());
                   startActivity(result);
               }
               else {
                   Toast.makeText(firstview.this, "Select all question", Toast.LENGTH_SHORT).show();
               }
           }
       });

    }
}